"""Integrity and stored metadata; use replay.py for mathematical recomputation."""
from pathlib import Path
import hashlib,gzip,json
HERE=Path(__file__).resolve().parent

def run():
 if not __debug__:raise RuntimeError('Do not use Python -O')
 manifest=json.loads((HERE/'SHA256SUMS.json').read_text())
 for name,wanted in manifest.items():
  path=(HERE/name).resolve();path.relative_to(HERE.resolve())
  assert path.is_file()and hashlib.sha256(path.read_bytes()).hexdigest()==wanted,name
 from bootstrap_matching import INPUT_SHA256
 config=json.loads((HERE/'release_config.json').read_text());d=json.load(gzip.open(HERE/'certificates.json.gz','rt'));cov=json.loads((HERE/'coverage.json').read_text())
 assert config['N']==d['N']==cov['N']==59 and config['CAP']==d['CAP']==79
 assert len(d['certificates'])==config['new_certificate_count']==cov['new_certificate_count']==231
 assert cov['q_strata']==154 and cov['parent_intervals']==43 and cov['passed']
 r=dict(passed=True,N=59,hashed_files=len(manifest),stored_certificates=231,frozen80_zip_sha256=INPUT_SHA256,scope='File integrity and stored counts only, not mathematical recomputation.')
 print(json.dumps(r,indent=2));return r
if __name__=='__main__':run()
