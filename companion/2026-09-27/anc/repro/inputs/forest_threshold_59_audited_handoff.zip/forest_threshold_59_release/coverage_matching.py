"""Exact continuous cover combining new count kernels with frozen all-scale kernels."""
from kernel_matching import *
from fractions import Fraction as Q
import json,gzip

def inherited():
 out=[]
 for path in [PRIOR99/'certificates.json.gz',PRIOR130/'bridge_certificates.json.gz',PRIOR170/'certificates_170.json.gz']:
  out+=json.load(gzip.open(path,'rt'))['certificates']
 assert len(out)==989
 # These older kernels do not contain the N-sensitive variance profiles
 # introduced in the80 package. They are reused as conditional-kernel bounds.
 assert all(c.get('variance_type')not in ['log_linear','log_integer_rank']for c in out)
 return out

def cover(new,N):
 if not __debug__:raise RuntimeError('Do not use -O')
 assert 8<=N<=CAP
 cs=inherited()+new;assert len({c['certificate_id']for c in cs})==len(cs)
 rows=json.load(open(ROOT350/'fixed_plan_350.json'))['rows'];large=json.load(gzip.open(ROOT350/'results/complete_350.json.gz','rt'))['rows'];out=[];prev=None
 for i,row in enumerate(rows):
  a,b=map(Q,row['activity']);qa,qb=a/(1+a),b/(1+b);assert prev is None or qa==prev;prev=qb
  ent=[c for c in cs if c['parent_index']==i];cuts=sorted({qa,qb}|{Q(c[k])for c in ent for k in ['qa','qb']});assert cuts[0]==qa and cuts[-1]==qb
  parts=[]
  for x,y in zip(cuts,cuts[1:]):
   guarantees=[(down(Q(c['kmin'])/(2*Q(c['qb']))),c['kmin'],c['certificate_id'])for c in new if c['parent_index']==i and Q(c['qa'])<=x<y<=Q(c['qb'])]
   if guarantees:start,rank_lower,guarantee_source=max(guarantees)
   else:
    cfg=prepare(i,x,y,N);start=cfg['mlo'];rank_lower=cfg['integer_rank_lower'];guarantee_source='fresh_density_bound'
   target=Q(large[i]['constants']['m']);end=start;used=[]
   intervals=sorted((Q(c['mlo']),Q(c['mhi']),c['certificate_id'],'empty'if c.get('empty')else'mixture_with_counts'if'counts'in c else c['method'])for c in ent if Q(c['qa'])<=x<y<=Q(c['qb']))
   for lo,hi,ident,kind in intervals:
    if lo>end:break
    if hi>end:end=hi;used.append(dict(certificate_id=ident,kind=kind))
   assert end>=target,('GAP',i,str(x),str(y),str(start),str(end),str(target))
   parts.append(dict(qa=str(x),qb=str(y),guaranteed_m_lower=str(start),rank_lower=rank_lower,guarantee_source=guarantee_source,inherited350_m_lower=str(target),covered_to=str(end),witnesses=used))
  out.append(dict(parent_index=i,activity=row['activity'],q_pieces=parts))
 assert len(rows)==43 and Q(rows[0]['activity'][0])==Q(1,3)and Q(rows[-1]['activity'][1])==Q(9,4)
 return dict(passed=True,N=N,new_finite_n_range=[N,CAP],inherited_n_range=[80,'infinity'],parent_intervals=43,q_strata=sum(len(r['q_pieces'])for r in out),new_certificate_count=len(new),reused99_kernel_certificates=188,reused130_kernel_certificates=243,reused170_kernel_certificates=558,total_finite_kernel_rectangles=len(cs),no80_N_dependent_kernel_reused=True,all_continuous_q_m_covered=True,all_discrete_n_k_cases_covered=True,proof_target='Every necessary coefficient exceeds at least one adjacent coefficient.',mean_m_is_real=True,rows=out)

