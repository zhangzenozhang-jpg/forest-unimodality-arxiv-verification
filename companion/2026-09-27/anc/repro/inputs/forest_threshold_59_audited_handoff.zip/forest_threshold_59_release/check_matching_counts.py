"""Independent integer-polynomial reconstruction of the matching count bounds."""
from fractions import Fraction as Q
from functools import lru_cache
from math import comb
from bootstrap_matching import up

@lru_cache(None)
def independent_envelopes(n):
 # Multiply (1+2x)^r (1+x)^(n-h-2r) by elementary integer updates,
 # rather than using the generator's closed binomial-sum expression.
 size=n//2+1;tail=[0]*size;tables=[None]*(n+2)
 tables[n+1]=tuple(tail)
 for h in range(n,-1,-1):
  r=max(0,n-2*h)
  if 2*r<=n-h:
   pol=[1]
   for w in [2]*r+[1]*(n-h-2*r):
    new=[0]*(len(pol)+1)
    for j,v in enumerate(pol):new[j]+=v;new[j+1]+=w*v
    pol=new
   assert all(v==0 for v in pol[size:])
   for y,v in enumerate(pol[:size]):tail[y]=max(tail[y],v)
  tables[h]=tuple(tail)
 return tuple(tables)

def env(n,y,M=0):
 if not 0<=y<=n//2 or M>n:return 0
 return independent_envelopes(n)[max(0,M)][y]
@lru_cache(None)
def independent_path(n,a):
 return sum(Q(comb(n-k+1,k))*a**k for k in range((n+1)//2+1))
@lru_cache(None)
def bound(n,y,qa,qb):
 if not 0<=y<=n//2:return Q(0)
 a,b=qa/(1-qa),qb/(1-qb)
 return up(Q(env(n,y))*b**y/independent_path(n,a))

def reconstruct(N,cap,qa,qb,r,kmin,kmax):
 pairs=[]
 for n in range(N,cap+1):
  for k in range(kmin,kmax+1):
   if 4*k<n or 2*k>n or Q(k)<r*n or Q(k)>qb*n:continue
   pairs.append([n,k])
 if not pairs:return dict(empty=True,pairs=[],j_values=[],upper_bounds=[])
 js=[];ubs=[]
 for j in range(min(k-n//2 for n,k in pairs),max(k for n,k in pairs)+1):
  v=max(bound(n,k-j,qa,qb)for n,k in pairs)
  if v>0:js.append(j);ubs.append(str(v))
 return dict(empty=False,pairs=pairs,j_values=js,upper_bounds=ubs,method='maximum_over_n_k_h_of_matching_coefficient_times_upper_activity_power_over_lower_path_partition')

def reconstruct_states(data,cap):
 return [(M,j)for M in range(cap+1)for j in data['j_values']if any(env(n,k-j,M)>0 for n,k in data['pairs'])]
