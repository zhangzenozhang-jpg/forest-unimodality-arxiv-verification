"""Optional numerical discovery for one rectangle, never a global theorem."""
from pathlib import Path
from fractions import Fraction as Q
import sys,json,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from kernel_matching import prepare,discover

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('parent_index',type=int)
    p.add_argument('--N',type=int,default=59)
    p.add_argument('--qa',type=Q,required=True)
    p.add_argument('--qb',type=Q,required=True)
    p.add_argument('--mlo',type=Q)
    p.add_argument('--mhi',type=Q)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--verify',action='store_true',help='Independently check this rectangle; does not prove full coverage.')
    a=p.parse_args()
    if not 0<=a.parent_index<43 or not 8<=a.N<=79:p.error('Require parent_index=0..42 and 8<=N<=79.')
    if not 0<a.qa<a.qb<1:p.error('Require 0<qa<qb<1.')
    cfg=prepare(a.parent_index,a.qa,a.qb,a.N)
    lo=a.mlo or cfg['mlo'];hi=a.mhi or min(cfg['mhi'],lo*Q(101,100))
    if not cfg['mlo']<=lo<hi<=cfg['mhi']:p.error('Requested mean rectangle outside the inherited bridge domain.')
    c=discover(cfg,lo,hi)
    if c.get('empty'):c.update(parent_index=a.parent_index,finite_n_max=79)
    if a.verify and not c.get('failed'):
        from check_matching_kernel import verify
        result=verify(c,inputs=True);c['exact_check']=result;c['certified']=bool(result['passed'])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(c,indent=2)+'\n')
    print('Single-rectangle output; complete coverage still required:',a.output)
