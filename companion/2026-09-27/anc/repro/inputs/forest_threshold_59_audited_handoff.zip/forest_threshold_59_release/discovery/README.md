# 可选发现，不属于默认接受路径

`discover_rectangle.py`寻找一个q×m矩形的候选，依赖NumPy/SciPy。可选`--verify`调用独立精确检查器，但只认证该矩形，不能代替全部q、m、n和必要秩的覆盖。

示例（在发行根目录运行）：

```bash
python discovery/discover_rectangle.py 11 --N 59 --qa 395/792 --qb 1/2 --mlo 17 --mhi 147/8 --output work/candidate.json --verify
```

数值求解器版本改变后，未必找到同一组系数；固定发行表的正确性不依赖重新发现能力。所有正式接受只读取固定有理数，不调用优化器。

研究下一门槛时，计数域、负顶点数费用和源项参数必须重新计算。发现工具不会自动替换`certificates.json.gz`或`coverage.json`。改变CAP需同步修改概率表、导数界、计数重构和验收器；不要只改命令行中的N。
