"""Candidate discovery for finite matching-count kernel bounds. Not acceptance."""
from bootstrap_matching import *
from matching_counts import count_data,states_allowed
from fractions import Fraction as Q
import json,gzip,time,math
from functools import lru_cache
prior_bridge.MMAX=79;prior_rates.CAP=79
NEW_VARIANCE_SOURCES=json.loads((HERE/'combo_sources/library.json').read_text())
for entry in NEW_VARIANCE_SOURCES:prior_variance.LIB.append(dict(file=entry['file'],parameters=entry['parameters']))
CAP=79

def prepare(i,qa,qb,N):
 rows=json.load(open(ROOT350/'fixed_plan_350.json'))['rows']
 return prior_rates.prepare(dict(rows[i],index=i),qa,qb,N)

@lru_cache(None)
def prob(M,j,q):
 if j<0 or j>M:return 0.
 from scipy.special import gammaln
 return math.exp(gammaln(M+1)-gammaln(j+1)-gammaln(M-j+1)+j*math.log(q)+(M-j)*math.log1p(-q))

def discover(cfg,ml,mh,profile=None,verbose=True):
 import numpy as np
 from scipy.optimize import linprog
 st=time.monotonic();qa,qb=cfg['qa'],cfg['qb'];kmin=cfg['integer_rank_lower'];kmax=(2*qb*mh).numerator//(2*qb*mh).denominator
 data=count_data(cfg['N'],CAP,qa,qb,cfg['r'],kmin,kmax)
 if data['empty']:return dict(empty=True,N=cfg['N'],qa=str(qa),qb=str(qb),mlo=str(ml),mhi=str(mh),kmin=kmin,kmax=kmax)
 profile=profile or prior_variance.choose(cfg,ml,mh)[0]
 pairs=states_allowed(data,CAP);M=np.array([x[0]for x in pairs],dtype=int);j=np.array([x[1]for x in pairs],dtype=int)
 qaf,qbf=float(qa),float(qb);mc=float((ml+mh)/2);qm=(qaf+qbf)/2;S=max(1,round(math.sqrt(2*math.pi)*(qm*(1-qm)*mc)**1.5));h2=(qbf-qaf)**2/8
 ts=np.array([float(Q(x['t']))for x in cfg['mgf']]);rates=np.array([float(Q(x['rate_lower']))for x in cfg['mgf']]);kt=len(ts)
 normals=10.**(-np.floor(mc*rates/math.log(10)))
 js=data['j_values'];ubs=np.array([float(Q(x))for x in data['upper_bounds']]);kj=len(js)
 cnorm=np.maximum(ubs,1e-10);jindex={v:i for i,v in enumerate(js)};inds=np.array([jindex[v]for v in j]);select=np.eye(kj)[inds]
 BC=np.array([float(v)for v in prior_bridge.derivative_bounds('central',qa,qb)])[M]
 BL=np.array([float(v)for v in prior_bridge.derivative_bounds('left',qa,qb)])[M]
 BR=np.array([float(v)for v in prior_bridge.derivative_bounds('right',qa,qb)])[M]
 mats=[];bs=[]
 for q in [qaf,qbf]:
  d=j-q*M;p=np.array([prob(int(mm),int(jj),q)for mm,jj in pairs]);pm=np.array([prob(int(mm),int(jj)-1,q)for mm,jj in pairs]);pp=np.array([prob(int(mm),int(jj)+1,q)for mm,jj in pairs])
  fc=2*p-pm-pp;fl=4*((1-q)*p-q*pm);fr=4*(q*p-(1-q)*pp)
  wc=fc-h2*BC;wl=fl-4*h2*BL;wr=fr-4*h2*BR
  lap=(1-q*(1-ts))[None,:]**M[:,None]
  lpp=M[:,None]*(M-1)[:,None]*(1-ts)[None,:]**2*(1-qaf*(1-ts))[None,:]**np.maximum(0,M-2)[:,None];lpp[M<2]=0
  gc=(1-q)**M;gcc=M*(M-1)*(1-qaf)**np.maximum(0,M-2);gcc[M<2]=0
  mat=np.c_[np.ones(len(M)),M-mc,d,-d*d+2*h2*M*M,-(M-mc)**2,-(lap-h2*lpp)/normals[None,:],-select*(gc-h2*gcc)[:,None]/cnorm[None,:],-S*(wl-wc),-S*(wr-wc),np.zeros(len(M))]
  mats.append(mat);bs.append(S*wc)
 nv=8+kt+kj;pay=[]
 for m in [float(ml),float(mh)]:pay.append(np.r_[-1.,-(m-mc),0.,float(profile['variance_slope'])*m+float(profile['variance_intercept']),float(cfg['D'])*m+(m-mc)**2,np.exp(-m*rates)/normals,ubs/cnorm,0.,0.,1.])
 normrow=np.zeros(nv);normrow[-3:-1]=1
 A=np.vstack([*mats,pay,normrow]);B=np.r_[*bs,0.,0.,1.]
 bounds=[(None,None)]*3+[(0,None)]*(2+kt+kj)+[(0,1),(0,1),(None,1.)];obj=np.zeros(nv);obj[-1]=-1
 ans=linprog(obj,A_ub=A,b_ub=B,bounds=bounds,method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
 if not ans.success:
  if verbose:print('COUNT_DUAL_FAIL',ans.status,ans.message,flush=True)
  return dict(failed=True,message=ans.message)
 x=ans.x;a=x[0]-x[1]*mc-x[4]*mc*mc;b=x[1]+2*x[4]*mc
 coeff=[a,b,x[2],x[3],x[4],*(x[5:5+kt]/normals),*(x[5+kt:5+kt+kj]/cnorm)]
 coeff=[Q(format(float(v),'.24e'))for v in coeff];coeff[0]-=Q(1,1000000)
 theta=[Q(math.floor(max(0.,min(1.,float(v)))*10**13),10**13)for v in x[-3:-1]]
 if sum(theta)>1:theta[1]=1-theta[0]
 weights=[4*theta[0],4*theta[1],1-sum(theta)]
 result={k:str(v)if isinstance(v,Q)else v for k,v in cfg.items()}
 result.update({k:str(v)if isinstance(v,Q)else v for k,v in profile.items()})
 result.update(mlo=str(ml),mhi=str(mh),kmin=kmin,kmax=kmax,counts=data,state_count=len(pairs),scale=S,coefficients=list(map(str,coeff)),kernel_weights=list(map(str,weights)),candidate_margin=float(x[-1]),certified=False)
 if verbose:print('COUNT_DUAL',cfg['parent_index'],str(qa),float(ml),float(mh),len(pairs),x[-1],weights,time.monotonic()-st,flush=True)
 return result

