"""Exact matching-envelope counts. No numerical computation in bound acceptance."""
from bootstrap_matching import *
from fractions import Fraction as Q
from functools import lru_cache
from math import comb

@lru_cache(None)
def match_coeff(vertices,edges,rank):
 assert isinstance(vertices,int)and isinstance(edges,int)and 0<=2*edges<=vertices
 if not 0<=rank<=vertices-edges:return 0
 return sum(comb(edges,a)*2**a*comb(vertices-2*edges,rank-a)for a in range(edges+1)if 0<=rank-a<=vertices-2*edges)
@lru_cache(None)
def envelope(n,y,Mmin=0):
 if not 0<=y<=n//2:return 0
 return max([match_coeff(n-h,max(0,n-2*h),y)for h in range(max((n+2)//3,Mmin),n-y+1)]+[0])
@lru_cache(None)
def path_partition(n,x):
 assert n>=0 and x>0
 a,b=Q(1),1+x
 for i in range(2,n+1):a,b=b,b+x*a
 return b if n else a

@lru_cache(None)
def ratio_bound(n,y,qa,qb):
 if not 0<=y<=n//2:return Q(0)
 a,b=qa/(1-qa),qb/(1-qb)
 return up(Q(envelope(n,y))*b**y/path_partition(n,a))

def ceilq(x):return (x.numerator+x.denominator-1)//x.denominator
@lru_cache(None)
def count_data(N,cap,qa,qb,r,kmin,kmax):
 assert 8<=N<=cap and 0<qa<qb<1 and r>0
 a,b=qa/(1-qa),qb/(1-qb)
 pairs=tuple((n,k)for n in range(N,cap+1)for k in range(max(kmin,ceilq(r*n),(n+3)//4),min(kmax,(qb*n).numerator//(qb*n).denominator,n//2)+1))
 if not pairs:return dict(empty=True,pairs=[],j_values=[],upper_bounds=[])
 jmin=min(k-n//2 for n,k in pairs);jmax=max(k for n,k in pairs)
 counts=[];js=[]
 for j in range(jmin,jmax+1):
  v=max((ratio_bound(n,k-j,qa,qb)for n,k in pairs),default=Q(0))
  if v>0:js.append(j);counts.append(up(v))
 return dict(empty=False,pairs=[list(p)for p in pairs],j_values=js,upper_bounds=list(map(str,counts)),method='maximum_over_n_k_h_of_matching_coefficient_times_upper_activity_power_over_lower_path_partition')

def states_allowed(data,cap):
 out=[]
 pairs=[tuple(x)for x in data['pairs']]
 for M in range(cap+1):
  for j in data['j_values']:
   if any(envelope(n,k-j,M)>0 for n,k in pairs):out.append((M,j))
 return out
