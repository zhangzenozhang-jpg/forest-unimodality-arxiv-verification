"""Invalid proofs are deliberately rejected; all edits are temporary copies."""
from pathlib import Path
from fractions import Fraction as Q
import copy,json,gzip,tempfile,sys,subprocess
from bootstrap_matching import HERE,ARCHIVE
from check_matching_kernel import verify
from coverage_matching import cover
from check_variance_source import verify as source_verify

def run():
 if not __debug__:raise RuntimeError('Do not use Python -O')
 data=json.load(gzip.open(HERE/'certificates.json.gz','rt'));cs=data['certificates'];original=next(c for c in cs if c['parent_index']==10 and not c.get('empty'));tests=[]
 def reject(name,mutator):
  c=copy.deepcopy(original);mutator(c)
  try:r=verify(c,inputs=True)
  except (AssertionError,ValueError):tests.append(dict(test=name,rejected=True,mechanism='exact_input_or_domain_reconstruction'));return
  assert not r['passed'],(name,'was accepted');tests.append(dict(test=name,rejected=True,mechanism=r['stage']))
 reject('forged_smaller_count_upper_bound',lambda c:c['counts']['upper_bounds'].__setitem__(0,'0'))
 reject('removed_admissible_n_k_pair',lambda c:c['counts']['pairs'].pop(0))
 reject('altered_target_rank_minimum',lambda c:c.update(kmin=c['kmin']+1))
 reject('altered_target_rank_maximum',lambda c:c.update(kmax=c['kmax']+1))
 reject('reused_count_certificate_at_smaller_N',lambda c:c.update(N=c['N']-1))
 reject('false_empty_rectangle',lambda c:c.update(empty=True))
 reject('unproved_larger_finite_state_cap',lambda c:c.update(finite_n_max=c['finite_n_max']+1))
 reject('forged_state_count',lambda c:c.update(state_count=c['state_count']-1))
 reject('negative_kernel_weight',lambda c:c['kernel_weights'].__setitem__(0,'-1'))
 reject('negative_count_penalty',lambda c:c['coefficients'].__setitem__(-1,'-1'))
 reject('stale_variance_intercept',lambda c:c.update(variance_intercept=str(Q(c['variance_intercept'])-1)))
 reject('false_pointwise_minorant',lambda c:c['coefficients'].__setitem__(0,str(Q(c['coefficients'][0])+1000000)))
 reject('negative_expected_budget',lambda c:c['coefficients'].__setitem__(0,str(Q(c['coefficients'][0])-1000000)))
 try:cover([c for c in cs if c['parent_index']!=10],data['N'])
 except AssertionError as e:
  assert e.args and isinstance(e.args[0],tuple)and e.args[0][0]=='GAP';tests.append(dict(test='missing_parent10_new_bridge',rejected=True,mechanism='continuous_cover_gap'))
 else:raise AssertionError('Missing parent bridge accepted')
 (HERE/'work').mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='negative_tests_',dir=HERE/'work')as tmp:
  tmp=Path(tmp);src=next((HERE/'combo_sources').glob('*.json.gz'));d=json.load(gzip.open(src,'rt'));d['rows'].pop(0);p=tmp/'source_gap.json.gz'
  with gzip.open(p,'wt')as f:json.dump(d,f)
  try:source_verify(p)
  except AssertionError:tests.append(dict(test='source_probability_cover_gap',rejected=True,mechanism='independent_scalar_checker'))
  else:raise AssertionError('Invalid source cover accepted')
  fake=tmp/'corrupt_capsule';(fake/'inputs').mkdir(parents=True)
  raw=bytearray(ARCHIVE.read_bytes());raw[100]^=1;(fake/'inputs'/ARCHIVE.name).write_bytes(raw)
  (fake/'bootstrap_matching.py').write_bytes((HERE/'bootstrap_matching.py').read_bytes())
  r=subprocess.run([sys.executable,'-S',str(fake/'bootstrap_matching.py')],capture_output=True,text=True)
  assert r.returncode!=0 and 'Missing or modified frozen80 input archive'in r.stderr
  tests.append(dict(test='corrupted_frozen_archive',rejected=True,mechanism='SHA256 mismatch'))
 r=subprocess.run([sys.executable,'-O','-S','-c','from check_matching_kernel import verify; verify({})'],cwd=HERE,capture_output=True,text=True)
 assert r.returncode!=0 and 'Do not use Python -O'in r.stderr
 tests.append(dict(test='disabled_assertions',rejected=True,mechanism='explicit -O refusal'))
 return dict(passed=True,negative_test_count=len(tests),all_deliberately_invalid_inputs_rejected=True,tests=tests)
if __name__=='__main__':
 r=run();(HERE/'work/latest_negative_tests.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
