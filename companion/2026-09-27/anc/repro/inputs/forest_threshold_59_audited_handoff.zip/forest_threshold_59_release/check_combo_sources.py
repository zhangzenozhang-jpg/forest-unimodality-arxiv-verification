"""Independent scalar reconstruction of the four added flow+log sources."""
from pathlib import Path
from functools import lru_cache
import json,gzip,time
from bootstrap_matching import HERE
from check_variance_source import verify

@lru_cache(None)
def ensure_sources():
    if not __debug__:raise RuntimeError('Do not use Python -O')
    start=time.monotonic();lib=json.loads((HERE/'combo_sources/library.json').read_text());assert len(lib)==4
    assert len({s['file']for s in lib})==len(lib);out=[]
    for ent in lib:
        path=(HERE/'combo_sources'/ent['file']).resolve();path.relative_to((HERE/'combo_sources').resolve())
        d=json.load(gzip.open(path,'rt'));assert d['parameters']==ent['parameters']
        assert 'flow'in d['parameters']and 'ell'in d['parameters']
        r=verify(path);assert r['passed'];out.append(r)
    return dict(passed=True,new_combined_source_count=len(out),probability_cells=sum(c['probability_cells']for c in out),retention_cells=sum(c['retention_cells']for c in out),parent_cases=sum(c['parent_cases']for c in out),real_response_region_checks=sum(c['response_regions']for c in out),all_source_polynomials_independently_reconstructed=True,checks=out,seconds=time.monotonic()-start)
if __name__=='__main__':
    r=ensure_sources();(HERE/'work').mkdir(exist_ok=True);(HERE/'work/latest_source_checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
