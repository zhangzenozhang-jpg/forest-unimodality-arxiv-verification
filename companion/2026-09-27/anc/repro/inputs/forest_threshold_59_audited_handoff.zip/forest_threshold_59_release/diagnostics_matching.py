"""Exact small-forest diagnostics; not the universal combinatorial proof."""
from itertools import combinations
from math import comb
from fractions import Fraction as Q
from matching_counts import envelope,match_coeff,path_partition
from check_matching_counts import independent_envelopes,env
import json,time
from pathlib import Path

def forest(n,edges):
 p=list(range(n))
 def root(v):
  while p[v]!=v:v=p[v]
  return v
 for u,v in edges:
  a,b=root(u),root(v)
  if a==b:return False
  p[a]=b
 return True

def run(maxn=6):
 start=time.monotonic();graphs=cases=identitychecks=coefficientchecks=0;counterexample_examples=[]
 for n in range(1,maxn+1):
  poss=list(combinations(range(n),2))
  for mask in range(1<<len(poss)):
   if mask.bit_count()>n-1:continue
   edges=[e for i,e in enumerate(poss)if mask>>i&1]
   if not forest(n,edges):continue
   graphs+=1;adj=[0]*n
   for u,v in edges:adj[u]|=1<<v;adj[v]|=1<<u
   inds=[s for s in range(1<<n)if all(not(s>>u&1 and s>>v&1)for u,v in edges)]
   cf=[sum(s.bit_count()==k for s in inds)for k in range(n+1)]
   for k in range((n+1)//2+1):assert cf[k]>=comb(n-k+1,k);coefficientchecks+=1
   for a,b in [(1,1),(2,3),(3,2)]:
    lam=Q(a,b);weights=[a**s.bit_count()*b**(n-s.bit_count())for s in inds];Z=sum(weights)
    marginal=[sum(w for s,w in zip(inds,weights)if s>>v&1)for v in range(n)]
    B=max(inds,key=lambda s:(sum(marginal[v]for v in range(n)if s>>v&1),s.bit_count()));h=B.bit_count();C=((1<<n)-1)^B
    assert 3*h>=n
    for v in range(n):
     if adj[v].bit_count()==1:
      u=(adj[v]&-adj[v]).bit_length()-1
      if adj[u].bit_count()>1:assert B>>v&1
    for v in range(n):
     if C>>v&1:assert adj[v]&B
    sub=[s for s in inds if s&C==s];ic=[sum(s.bit_count()==y for s in sub)for y in range(n-h+1)]
    assert max(s.bit_count()for s in sub)<=n//2
    eC=[(u,v)for u,v in edges if C>>u&1 and C>>v&1];r=max(0,n-2*h)
    best=0
    for em in range(1<<len(eC)):
     vertices=0;ok=True
     for t,(u,v)in enumerate(eC):
      if em>>t&1:
       bits=(1<<u)|(1<<v)
       if bits&vertices:ok=False;break
       vertices|=bits
     if ok:best=max(best,vertices.bit_count()//2)
    assert best>=r
    for y,c in enumerate(ic):
     assert c<=match_coeff(n-h,r,y)<=envelope(n,y);coefficientchecks+=1
    # Direct conditional summation and coefficient-by-coefficient cancellation.
    z2=Q(0);groups={}
    for s in sub:
     blocked=0
     for v in range(n):
      if s>>v&1:blocked|=adj[v]&B
     M=h-blocked.bit_count();y=s.bit_count();mass=lam**y*(1+lam)**M
     z2+=mass;groups[y]=groups.get(y,Q(0))+mass*(1+lam)**(-M)
     assert envelope(n,y,M)>0
    assert z2==Q(Z,b**n)
    for y,g in groups.items():assert g==ic[y]*lam**y;identitychecks+=1
    # Additional exchange-square lemma, not needed by the released count bridge.
    WB=sum(marginal[v]for v in range(n)if B>>v&1);WC=sum(marginal[v]for v in range(n)if C>>v&1);q=lam/(1+lam)
    assert sum(marginal[v]**2 for v in range(n)if C>>v&1)+sum(Q(marginal[v]**2)/q for v in range(n)if B>>v&1)<=WB*Z
    if h and n-h:assert Q(WB*WB)/(q*h)+Q(WC*WC,n-h)<=WB*Z
    cases+=1
  print('DIAGNOSTIC_N',n,'forests',graphs,'cases',cases,flush=True)
 # Independent count convolution checks for every n used in the new finite cap.
 envchecks=0
 for n in range(1,80):
  for M in range(n+1):
   for y in range(n//2+1):assert envelope(n,y,M)==env(n,y,M);envchecks+=1
 return dict(passed=True,max_enumerated_vertices=maxn,labeled_forests=graphs,activity_forest_cases=cases,conditional_cancellation_identities=identitychecks,coefficient_count_checks=coefficientchecks,independent_matching_envelope_checks=envchecks,standard_library_only=True,scope='Finite implementation diagnostics; universal claims use the written leaf/matching and partition-function proofs.',seconds=time.monotonic()-start)
