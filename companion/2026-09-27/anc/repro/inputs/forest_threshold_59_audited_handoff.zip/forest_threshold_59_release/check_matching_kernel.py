"""Independent exact acceptance of matching-count kernel rectangles."""
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
from math import comb,lcm
import json,time,sys
from kernel_matching import CAP,prepare,prior_variance,prior_bridge
from check_matching_counts import reconstruct as count_data,reconstruct_states as states_allowed
from bootstrap_matching import down,exp_neg_hi
P=10**70

def ceildiv(a,b):return -((-a)//b)
def upper(x):x=Q(x);return ceildiv(x.numerator*P,x.denominator)
@lru_cache(None)
def probabilities(q):
 q=Q(q);a,b=q.numerator,q.denominator;c=b-a;assert 0<a<b
 out=[]
 for M in range(CAP+1):
  den=b**M;nums=[comb(M,j)*a**j*c**(M-j)for j in range(M+1)]
  lo=[v*P//den for v in nums];hi=[ceildiv(v*P,den)for v in nums]
  assert sum(lo)<=P<=sum(hi);out.append((lo,hi))
 return out
@lru_cache(None)
def powers(q,t):
 w=1-Q(q)+Q(q)*Q(t);a,b=w.numerator,w.denominator;assert 0<a<b
 lo=[P];hi=[P]
 for _ in range(CAP):lo.append(lo[-1]*a//b);hi.append(ceildiv(hi[-1]*a,b))
 return lo,hi

def verify(c,inputs=True):
 if not __debug__:raise RuntimeError('Do not use Python -O')
 st=time.monotonic()
 if inputs:
  from check_combo_sources import ensure_sources
  ensure_sources()
 qa,qb=Q(c['qa']),Q(c['qb']);ml,mh=Q(c['mlo']),Q(c['mhi']);N=c['N']
 assert isinstance(N,int)and 8<=N<=CAP and 0<qa<qb<1 and 0<ml<mh
 cfg=prepare(c['parent_index'],qa,qb,N)
 assert ml>=cfg['mlo'] and mh<=cfg['mhi']
 kmin=cfg['integer_rank_lower'];v=2*qb*mh;kmax=v.numerator//v.denominator
 counts=count_data(N,CAP,qa,qb,cfg['r'],kmin,kmax)
 assert c['kmin']==kmin and c['kmax']==kmax
 if c.get('empty'):
  assert counts['empty'];return dict(passed=True,empty=True,all_continuous_domains=True,seconds=time.monotonic()-st)
 assert not counts['empty']and c['counts']==counts
 for k in ['r','D','CW','vmax']:assert Q(c[k])==cfg[k],k
 assert c['finite_n_max']==CAP and c['mgf']==cfg['mgf']
 profiles=prior_variance.options(cfg,ml,mh)
 def matches(p):
  return all((Q(c[k])==v if isinstance(v,Q)else c[k]==v)for k,v in p.items())
 assert any(matches(x)for x in profiles),'variance profile mismatch'
 ws=list(map(Q,c['kernel_weights']));assert len(ws)==3 and min(ws)>=0 and ws[0]/4+ws[1]/4+ws[2]==1
 coef=list(map(Q,c['coefficients']));kt=len(cfg['mgf']);kj=len(counts['j_values']);assert len(coef)==5+kt+kj and min(coef[3:])>=0
 L=lcm(*(v.denominator for v in coef+ws));cc=[v.numerator*(L//v.denominator)for v in coef];WW=[v.numerator*(L//v.denominator)for v in ws]
 A,B,C,D,E,*rest=cc;Ts=rest[:kt];Us=rest[kt:];Umap=dict(zip(counts['j_values'],Us));S=c['scale'];assert isinstance(S,int)and S>0
 tvals=[Q(x['t'])for x in cfg['mgf']];assert all(0<t<1 for t in tvals)
 deriv=[[upper(v)for v in prior_bridge.derivative_bounds(method,qa,qb)]for method in ['left','right','central']]
 lpowers=[powers(qa,t)[1]for t in tvals];cphi=powers(qa,Q(0))[1];h2=(qb-qa)**2/8
 base_second=[]
 for M in range(CAP+1):
  sec=S*sum(w*d[M]for w,d in zip(WW,deriv))+2*D*M*M*P
  if M>=2:
   for T,t,pow in zip(Ts,tvals,lpowers):sec+=T*ceildiv(M*(M-1)*(t.denominator-t.numerator)**2*pow[M-2],t.denominator**2)
  base_second.append(sec)
 pairs=states_allowed(counts,CAP);assert c['state_count']==len(pairs)
 min_res=None;checks=0
 for q in [qa,qb]:
  qn,qd=q.numerator,q.denominator;probs=probabilities(q);pp=[powers(q,t)[0]for t in tvals];pc=powers(q,Q(0))[0]
  caches={}
  for M,j in pairs:
   if M not in caches:
    lo,hi=probs[M];lap=sum(T*p[M]for T,p in zip(Ts,pp));base=(-A-B*M+E*M*M)*qd*qd*P+lap*qd*qd;caches[M]=(lo,hi,base)
   lo,hi,base=caches[M];U=Umap[j];sec=base_second[M]+(U*M*(M-1)*cphi[M-2]if M>=2 else 0)
   corr=ceildiv(h2.numerator*qd*qd*sec,h2.denominator)
   def at(arr,k):return arr[k]if 0<=k<=M else 0
   wl,wr,wc=WW
   kernel_num=(wl*(qd-qn)+wr*qn+2*wc*qd)*at(lo,j)-(wl*qn+wc*qd)*at(hi,j-1)-(wr*(qd-qn)+wc*qd)*at(hi,j+1)
   kernel=kernel_num//qd
   dn=j*qd-M*qn
   rr=base+U*pc[M]*qd*qd-corr+P*(-C*dn*qd+D*dn*dn)+S*qd*qd*kernel
   val=Q(rr,P*L*qd*qd);min_res=val if min_res is None else min(min_res,val);checks+=1
   if rr<0:return dict(passed=False,stage='pointwise',q=str(q),M=M,j=j,residual_lower=str(down(val)),seconds=time.monotonic()-st)
 alpha,beta=Q(c['variance_slope']),Q(c['variance_intercept']);dm=cfg['D'];pay=[]
 count_cost=sum(Q(U,L)*Q(b)for U,b in zip(Us,counts['upper_bounds']))
 for m in [ml,mh]:
  v=Q(A,L)+Q(B,L)*m-Q(D,L)*(alpha*m+beta)-Q(E,L)*(m*m+dm*m)-count_cost
  for T,rate in zip(Ts,cfg['mgf']):v-=Q(T,L)*exp_neg_hi(m*Q(rate['rate_lower']))
  v=down(v);pay.append(v)
  if v<=0:return dict(passed=False,stage='payoff',m=str(m),margin_lower=str(v),seconds=time.monotonic()-st)
 return dict(passed=True,empty=False,endpoint_integer_state_checks=checks,discrete_n_k_pairs=len(counts['pairs']),conditional_count_constraints=kj,minimum_endpoint_residual_lower=str(down(min_res)),payoff_endpoint_lower=list(map(str,pay)),margin_lower=str(min(pay)),all_continuous_q_m_covered=True,all_admissible_integer_states_covered=True,arithmetic='integer outward intervals and exact Fraction parameters; no floating acceptance',seconds=time.monotonic()-st)
