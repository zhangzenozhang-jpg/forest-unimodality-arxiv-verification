"""Relocation check: all new sources, three kernels, and complete geometry."""
from pathlib import Path
import json,gzip,time,sys
HERE=Path(__file__).resolve().parent

def run():
 if not __debug__:raise RuntimeError('Do not use Python -O')
 start=time.monotonic()
 from check_combo_sources import ensure_sources
 from check_matching_kernel import verify
 from coverage_matching import cover
 src=ensure_sources();d=json.load(gzip.open(HERE/'certificates.json.gz','rt'));cs=d['certificates'];out=[]
 ids=sorted({0,len(cs)//2,len(cs)-1})
 for i in ids:
  r=verify(cs[i],inputs=True);assert r['passed'];out.append(dict(certificate_id=cs[i]['certificate_id'],passed=True))
 geometry=cover(cs,d['N']);assert geometry==json.loads((HERE/'coverage.json').read_text())
 assert 'numpy'not in sys.modules and 'scipy'not in sys.modules
 r=dict(passed=True,N=d['N'],execution_root=str(HERE),all_four_new_sources_independently_reconstructed=True,representative_kernel_checks=out,all_continuous_geometry_verified=True,q_strata=geometry['q_strata'],site_initialization_disabled=bool(sys.flags.no_site),numerical_optimizer_used=False,seconds=time.monotonic()-start,scope='Relocation validation, not a replacement for full old-chain and all-kernel replay.')
 (HERE/'work/latest_smoke_check.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));return r
if __name__=='__main__':run()
