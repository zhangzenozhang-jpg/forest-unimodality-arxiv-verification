"""Full exact replay; discovery/optimization is never called by acceptance."""
from pathlib import Path
from fractions import Fraction as Q
import argparse,gzip,json,sys,subprocess,time
HERE=Path(__file__).resolve().parent

def load(p):return json.load(gzip.open(p,'rt'))if str(p).endswith('.gz')else json.loads(Path(p).read_text())
def stable(v):
 if isinstance(v,dict):return {k:stable(x)for k,x in v.items()if k not in ['seconds','elapsed_seconds']}
 if isinstance(v,list):return [stable(x)for x in v]
 return v

def run(skip_prior=False):
 if not __debug__:raise RuntimeError('Do not use Python -O')
 start=time.monotonic();preloaded={x for x in ['numpy','scipy']if x in sys.modules}
 from bootstrap_matching import PRIOR,INPUT_SHA256,ROOT350
 previous=None
 if not skip_prior:
  subprocess.run([sys.executable,'-S','-u',str(PRIOR/'replay.py')],cwd=PRIOR,check=True)
  previous=load(PRIOR/'work/latest_replay_summary.json')
  assert previous['N']==80 and previous['all_new_exact_certificates_passed']and previous['full_frozen99_chain_replayed']
 from check_combo_sources import ensure_sources
 sources=ensure_sources();print('NEW_SOURCES_PASS',sources['new_combined_source_count'],flush=True)
 from kernel_matching import CAP
 from check_matching_kernel import verify
 from coverage_matching import cover,inherited
 from diagnostics_matching import run as diagnostics_run
 config=load(HERE/'release_config.json');data=load(HERE/'certificates.json.gz');N=config['N'];cs=data['certificates']
 assert 8<=N<60 and CAP==79 and data['N']==N and data['CAP']==CAP and len(cs)==config['new_certificate_count']
 assert len({c['certificate_id']for c in cs})==len(cs)
 checks=[]
 for i,c in enumerate(cs):
  assert c['N']==N and c['certified']is True
  r=verify(c,inputs=True);assert r['passed'],(c['certificate_id'],r)
  assert stable(r)==stable(c['exact_check']),(c['certificate_id'],'stored exact check mismatch')
  checks.append(dict(certificate_id=c['certificate_id'],parent_index=c['parent_index'],scale=c.get('scale'),kernel_weights=c.get('kernel_weights'),**r))
  if i%20==0 or i==len(cs)-1:print('MATCHING_KERNEL',i+1,'/',len(cs),'PASS',flush=True)
 geometry=cover(cs,N);assert geometry==load(HERE/'coverage.json')
 # Validate the inherited unbounded-m bridge independently of any graph order.
 from bootstrap_optimized import prior_bridge as p130
 old=load(ROOT350/'results/complete_350.json.gz')['rows'];rows=load(ROOT350/'fixed_plan_350.json')['rows']
 for i,(row,result)in enumerate(zip(rows,old)):
  cfg=p130.frozen_bridge.prepare(dict(row,index=i),N=350)
  assert cfg['mhi']==Q(result['constants']['m'])and result['all_larger_m_monotonicity_checked']and Q(result['margin_lower'])>0
  for a,b in [('D','D'),('R','RR'),('r','r'),('vmax','vmax')]:assert cfg[a]==Q(result['constants'][b])
 diag=diagnostics_run()
 assert not ({x for x in ['numpy','scipy']if x in sys.modules}-preloaded)
 nonempty=[r for r in checks if not r['empty']];minimum=min(nonempty,key=lambda r:Q(r['margin_lower']))
 summary=dict(N=N,previous_N=80,new_finite_vertex_range=[N,CAP],inherited_vertex_range=[80,'infinity'],new_certificate_count=len(cs),all_new_exact_certificates_passed=True,all_continuous_q_m_covered=True,all_discrete_n_k_cases_covered=True,q_strata=geometry['q_strata'],parent_intervals=43,total_finite_kernel_rectangles=geometry['total_finite_kernel_rectangles'],reused99_kernel_certificates=188,reused130_kernel_certificates=243,reused170_kernel_certificates=558,no80_N_dependent_kernel_reused=True,all_new_variance_profiles_recomputed_at_declared_N=True,matching_counts_independently_reconstructed=True,total_endpoint_integer_state_checks=sum(r.get('endpoint_integer_state_checks',0)for r in checks),total_admissible_n_k_pair_checks=sum(r.get('discrete_n_k_pairs',0)for r in checks),minimum_normalized_margin_lower=minimum['margin_lower'],minimum_margin_certificate=minimum['certificate_id'],minimum_margin_scale=minimum['scale'],minimum_margin_kernel_weights=minimum['kernel_weights'],source_summary={k:v for k,v in sources.items()if k!='checks'},full_frozen80_chain_replayed=not skip_prior,frozen80_zip_sha256=INPUT_SHA256,diagnostics=diag,floating_point_acceptance=False,numerical_optimizer_used=False,site_initialization_disabled=bool(sys.flags.no_site),optional_modules_preloaded_by_environment=sorted(preloaded),seconds=time.monotonic()-start,scope='Research theorem conditional on explicitly declared inherited structural lemmas. Exact source proofs, matching-count reconstruction, and full continuous/discrete coverage; not proof-assistant formalization.')
 if previous:summary['prior80_replay_summary']=previous
 work=HERE/'work';work.mkdir(exist_ok=True)
 for name,d in [('latest_replay_summary.json',summary),('latest_kernel_checks.json',checks),('latest_source_checks.json',sources)]:
  (work/name).write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items()if k!='prior80_replay_summary'},indent=2),flush=True);return summary
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--skip-prior',action='store_true');a=p.parse_args();run(a.skip_prior)
