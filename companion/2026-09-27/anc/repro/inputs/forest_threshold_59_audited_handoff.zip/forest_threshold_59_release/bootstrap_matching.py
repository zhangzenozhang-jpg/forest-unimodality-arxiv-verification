"""Frozen80 input, safe extraction, file hashes, and inherited exact formulas."""
from pathlib import Path
import hashlib,json,sys,zipfile
HERE=Path(__file__).resolve().parent
ARCHIVE=HERE/'inputs/forest_threshold_80_audited_handoff.zip'
INPUT_SHA256='d1eb9f2903b554475634a3f0fac59d625ae196fdbe0525e6cfc6a97071742f03'
if not ARCHIVE.is_file()or hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()!=INPUT_SHA256:
    raise ValueError('Missing or modified frozen80 input archive')
DEST=HERE/'work/input';PRIOR=DEST/'forest_threshold_80_release'
with zipfile.ZipFile(ARCHIVE)as archive:
    manifest_bytes=archive.read('forest_threshold_80_release/SHA256SUMS.json')
    manifest=json.loads(manifest_bytes)
    if not (PRIOR/'SHA256SUMS.json').is_file():
        DEST.mkdir(parents=True,exist_ok=True)
        if archive.testzip()is not None:raise ValueError('Frozen input ZIP CRC failure')
        for ent in archive.infolist():
            (DEST/ent.filename).resolve().relative_to(DEST.resolve())
            if (ent.external_attr>>16)&0o170000==0o120000:raise ValueError('Symlink in input archive')
        archive.extractall(DEST)
if (PRIOR/'SHA256SUMS.json').read_bytes()!=manifest_bytes:
    raise ValueError('Frozen80 manifest mismatch')
for name,wanted in manifest.items():
    p=(PRIOR/name).resolve();p.relative_to(PRIOR.resolve())
    if not p.is_file()or hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:
        raise ValueError('Frozen80 file mismatch: '+name)
sys.path.insert(0,str(PRIOR))
import bridge_compressed as prior_bridge
import rates_compressed as prior_rates
import variance_compressed as prior_variance
from bootstrap_compression import ROOT350,PRIOR99,PRIOR130,PRIOR170
from exact_arithmetic import up,down,exp_neg_lo,exp_neg_hi,sqrt_lo,sqrt_hi
from verify_source_standalone import logbounds
